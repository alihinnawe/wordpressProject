<?php 
// Anpassungsmöglichkeit zur Deaktivierung bestimmter Blöcke für alle BenutzerInnen für blocks.php

function filter_allowed_blocks( $allowed_block_types) {
	if ( false === $allowed_block_types ) {
		return $allowed_block_types;
	}
	
	$blocks_to_remove = [
		'core/pullquote',
		'core/verse',
	];
	if(is_array($allowed_block_types)){
		foreach($allowed_block_types as $key => $block_type){
			if(! in_array($block_type, $blocks_to_remove,true)){
				continue;
			}
			unset($allowed_block_types[$key]);
			}
		return $allowed_block_types;
		}
		$tmp = WP_Block_Type_Registry::get_instance()->get_all_registered();
		$allowed_block_types =[];
		foreach(($tmp as $block_name => $block_object)
			if(in_array($block_name,$blocks_to_remove,true){
				continue;
			}
			$allowed_block_types[]=$block_name;
		)
		return $allowed_block_types;
		add_filter ('allowed_block_types_all',
	__NAMESPACE__ . '\\filter_allowed_blocks',
	10);
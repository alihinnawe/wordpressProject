<?php
namespace WH\Talks;
use WP_Block_Type_Registry;
function register_blocks(){
	register_block_type(
		__DIR__ . '/../build'
	);
}
add_action('init', __NAMESPACE__ . '\\register_blocks')

function remove_editor_modification_script_from_widget_screen(){
	global $block_editor_context;
	$context_name=$block_editor_context->name ?? null;
	if('core/edit-widgets' !== $context_name){
		return;
	}
	wp_deregister_script('wh-talks-modification-editor-script');
}
add_action('enqueue_block_editor_assets', __NAMESPACE__ . '\\remove_editor_modifications_script_from_widgets_screen');

function enqueue_editor_assets(){
	wp_localize_script(
		'wh-talks-meta-list-editor-script',
		'whTalksObject',
		[
			'metas'=>get_string_metas(),
		]
	);
}
/*var whTalksObject ={var whTalksObject = {"metas":[{"key":"wh_talks_event_name","label":"Event"},{"key":"wh_talks_language","label":"Language"},{"key":"wh_talks_duration","label":"Duration"},{"key":"wh_talks_video_link","label":"Video"},{"key":"wh_talks_slides_link","label":"Slides"}]};*/

register_block_type(
	__DIR__ . '/../build/blocks/meta-list',
	[
		'render_callback' => __NAMESPACE__ . '\\render_meta_list_block',
	]
	__DIR__ . '/../build/blocks/single-meta',
	[
		'render_callback' => __NAMESPACE__ . '\\render_single_meta_block',
	]
);
function render_meta_list_block( $attributes, $block_content ) {
	// return 'Meta-List-Block';
	$markup = '';
	foreach(get_string_metas() as $meta){
		$meta_key=$meta['key'] ?? null;
		$meta_label = $meta['label'] ?? null;
		if(empty($meta_key) || empty($meta_label)){
			continue;
		}
		$meta_value_markup = get_meta_value_markup($meta_key);
		if(empty($meta_value_markup)){
			continue;
		}
		$markup .=sprintf(
			'<li><span class="wh-talks-meta-label">%s:</span>%s</li>',
			$meta_label,
			$meta_value_markup
		);
	}
	if('' === $markup){ return '';}
	return str_replace('</ul>',"$markup</ul>", $block_content);
}
/*
str_replace(
    array|string $search,
    array|string $replace,
    string|array $subject,
    int &$count = null
): string|array
*/
function get_meta_value_markup($meta_key){
	$meta_value = get_post_meta(get_the_ID(),$meta_key,true) ?? null;
	if(empty($meta_value)){
		return '';
	}
	if(strrpos($meta_key,'_link') !== strlen($meta_key) - strlen('_link')){
		return esc_html($meta_value);
	}
	if(1 !== preg_match('/^(http:|https:)?\/\//',$meta_value)){
		return '';
	}
	$url = esc_url($meta_value);
	$host = parse_url($url,PHP_URL_HOST);
	return sprintf(
		'<a href="%s">%s</a>',
		$url,
		$host
	);
}

function render_single_meta_block($attributes, $block_content){
	// return 'Single meta block';
	$meta_key = $attributes['metaKey'] ?? null;
	if(empty($meta_key)){
		return '';
	}
	$meta_value_markup = get_meta_value_markup($meta_key);
	if(empty($meta_value_markup)){
		return '';
	}
	$label = $attributes['label'] ?? null;
	if(empty($label)){
		return str_replace('</p>',"$meta_value_markup</p>",$block_content);
	}
	return str_replace('</p>',"<span class='wh-talks-meta-label'>$label</span> $meta_value_markup</p>",$block_content)
}
function get_meta_value_markup($meta_key){
	$allowed_meta = false;
	foreach(get_string_metas() as $meta){
		if($meta_key !== $meta['key']){
			continue;
		}
		$allowed_meta = true;
			break;
		}
		if(!$allowed_meta){
			return '';
		}
		$meta_value = get_post_meta(get_the_ID(),$meta_key,true) ?? null;
}
// Anpassungsmöglichkeit zur Deaktivierung bestimmter Blöcke für alle BenutzerInnen in allowedBlocks.php
function filter_allowed_blocks( $allowed_block_types, $block_editor_context ) {
	if (
		'talk' === get_post_type()
		|| 'core/edit-site' === $block_editor_context->name
	) {
		return $allowed_block_types;
	}
	if ( false === $allowed_block_types ) {
		return $allowed_block_types;
	}
	
	$blocks_to_remove = [
		'wh-talks/meta-list',
		'wh-talks/single-meta',
	];
	if ( is_array( $allowed_block_types ) ) {
		foreach ( $allowed_block_types as $key => $block_type ) {
			if ( ! in_array( $block_type, $blocks_to_remove, true ) ) {
				continue;
			}
			unset( $allowed_block_types[ $key ] );
		}
		return $allowed_block_types;
	}
	$tmp = \WP_Block_Type_Registry::get_instance()->get_all_registered();
	$allowed_block_types = [];
	foreach ( $tmp as $block_name => $block_object ) {
		if ( in_array( $block_name, $blocks_to_remove, true ) ) {
			continue;
		}
		$allowed_block_types[] = $block_name;
	}
	return $allowed_block_types;
}
add_filter(
	'allowed_block_types_all',
	__NAMESPACE__ . '\\filter_allowed_blocks',
	10,
	2
);
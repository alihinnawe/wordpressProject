<?php
/**
 * Plugin Name: Talks
 * Description: Managing talks you gave.
 * Author: cms course
 * Author URI: https://example.com /
 * Version: 0.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.0
 * Text Domain: wh-talks
 */
 
 namespace WH\Talks;
 
 register_activation_hook(__FILE__,function(){
	 register_cpt();
	 flush_rewrite_rules();
 });
 register_deactivation_hook(__FILE__,function(){
	 flush_rewrite_rules();
 });
 // Actionhook für LOCO Plugin und Verzeichnis Language
 add_action('init',function():void{
 load_plugin_textdomain(domain: 'wh-talks',deprecated:false,dirname(path:plugin_basename(...__FILE__)).'/language')});
 }
 register_uninstall_hook(
	__FILE__,
	__NAMESPACE__ .'\\uninstall'
 );
 function uninstall(){
	 $post_ids = get_posts([
		'post_type' => 'talk',
		'post_status' => 'any',
		'numberposts' => -1,
		'fields' => 'ids',
	 ]);
	foreach($post_ids as $post_id){
		wp_delete_post($post_id,true);
	}
 }
 require_once 'inc/cpt.php';
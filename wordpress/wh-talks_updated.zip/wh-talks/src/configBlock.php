<?php
/*

{   "name":"wh-talks/editor-modifications",
	"editorScript":"file:./index.js"
}
{
	"$schema": "https://schemas.wp.org/trunk/block.json",
	"apiVersion":2, 
	"name": "wh-talks/meta-list",
	"version":"0.1.0",
	"title": "Talk metadata list",
	"icon":"megaphone",
	"description":"Display the talk metadata as list",
	"supports":{
		"html":false,
		"align":true
	},
	"textdomain":"wh-talks",
	"editorScript":"file:./index.js"
}

Konfiguration bestehender Blöcke in der Block.json - Datei
*/

add_filter(
	'block_type_metadata',
	function($metadata){
		$block_name = $metadata['name'] ?? null;
		if('core/heading' !== $block_name){
			return $metadata;
		}
		$metadata['supports']['typography']['__experimentalFontFamily']=true;
		return $metadata;
		},
		10,2
);


wp.domReady(() => {
	let actionDone = false;
	wp.data.subscribe(() =>
		{
			if(actionDone){
			return;
			}
		const postType = wp.data
			.select('core/editor')
			.getCurrentPostType();
		
			if(postType === null){
			return;
			}
			if('page' === postType){
				wp.data
					.dispatch('core/edit-post')
					.removeEditorPanel('featured-image');
			}
			actionDone = true;
			});
		});
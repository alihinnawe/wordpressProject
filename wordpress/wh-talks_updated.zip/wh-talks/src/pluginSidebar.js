import {registerPlugin}from '@wordpress/plugins';
import {PluginSidebar} from '@wordpress/edit-post';
import {useEntityProp} from '@wordpress/core-data';
import {CheckBoxControl,PanelBody} from '@wordpress/components';
import{__} from '@wordpress/i18n';
registerPlugin('wh-talks-sidebar', render:() => {
	if('talk' !== wp.data.select('core/editor').getCurrentPostType()){
		return null;
}
	const [meta,setMeta] = useEntityProp('postType','talk','meta');
	const updateMeta = (newValue) =>{
		setMeta({...meta,wh_talks_is_highlight: newValue});
	};
	const checked = meta?.wh_talks_is_highlight;
	return(
		<PluginSidebar
		name = 'wh-talks-sidebar'
		title = {__('Talk Sidebar','wh-talks')}
		icon = 'megaphone'
		>
			<PanelBody>
				<CheckboxControl
					label = {'Highlight','wh-talks'}
					ckecked = {checked}
					onChange = {()=>{updateMeta(!checked);}}
				
				/>
			</PanelBody>
		</PluginSidebar>
	)
	
)

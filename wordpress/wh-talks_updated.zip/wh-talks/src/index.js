/*
import sidebar - panel
import Pluginsidebar
import deactivatePic
*/
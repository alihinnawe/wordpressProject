<?php

add_action('init',function(){
	add_shortcode('wh_post_teaser', function($atts){
		$post_id=$atts['id'] ?? 0;
		if(empty($post_id)){
			return '';
		}
		$post_to_show = get_post($post_id);
		if($post_to_show === null){
			return '';
		}
		$default_heading_level = 2;
		$atts = shortcode_atts(
			array(
				'title' => $post_to_show->post_title,
				'content'=>get_the_excerpt($post_to_show),
				'heading_level' => $default_heading_level
			),
			$atts);
			if(empty($atts['title'])){
				return '';
			}
			$heading_level = $atts['heading_level'];
			if(!is_numeric($heading_level)){
				$heading_level = $default_heading_level;
			}
			return sprintf(
				'<div class="wh-post-teaser">
				<h%1$s><a href="%2$s">%3$s</a></h%1$s>
				<div class="wh-post-teaser-content">%4$s</div></div>',
				$heading_level,
				get_the_permalink($post_to_show),
				$atts['title'],
				$atts['content'] !== '' ? apply_filter ('the content', $atts['content']):'');
			});
		});
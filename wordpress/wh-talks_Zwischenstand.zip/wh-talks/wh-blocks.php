<?php

	require_once 'inc/blocks.php';
	import './sidebar-panel';
<?php
/**
 * Plugin Name: Talks
 * Description: Managing talks you gave.
 * Author: cms course
 * Author URI: https://example.com /
 * Version: 0.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.0
 * Text Domain: wh-talks
 */
 
 namespace WH\Talks;
 
 register_activation_hook(__FILE__,function(){
	 register_cpt();
	 flush_rewrite_rules();
 });
 register_deactivation_hook(__FILE__,function(){
	 flush_rewrite_rules();
 });
 require_once 'inc/cpt.php';